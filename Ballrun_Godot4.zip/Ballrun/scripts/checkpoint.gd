extends Area2D

signal activated(spawn_position: Vector2)

var is_active := false

func _ready() -> void:
    collision_layer = 0
    collision_mask = 1
    var hitbox := CollisionShape2D.new()
    var shape := CircleShape2D.new()
    shape.radius = 36.0
    hitbox.shape = shape
    hitbox.position = Vector2(0.0, -14.0)
    add_child(hitbox)
    body_entered.connect(_on_body_entered)

func _draw() -> void:
    draw_line(Vector2(0, 4), Vector2(0, -70), Color("f1e5c6"), 5.0, true)
    var flag_color := Color("7fe0b0") if is_active else Color("e7a76e")
    draw_colored_polygon(PackedVector2Array([Vector2(2,-68),Vector2(39,-57),Vector2(2,-43)]), flag_color)
    draw_circle(Vector2(0, 5), 8.0, Color("e8d8b7"))
    if is_active:
        draw_circle(Vector2(0, -20), 22.0, Color(0.45, 1.0, 0.75, 0.12))

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player") and not is_active:
        is_active = true
        queue_redraw()
        activated.emit(Vector2(global_position.x, global_position.y - 24.0))
