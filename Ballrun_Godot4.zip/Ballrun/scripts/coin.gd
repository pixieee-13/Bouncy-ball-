extends Area2D

signal collected(value: int)

@export var value := 1
var clock := 0.0
var start_y := 0.0

func _ready() -> void:
    collision_layer = 0
    collision_mask = 1
    var hitbox := CollisionShape2D.new()
    var shape := CircleShape2D.new()
    shape.radius = 20.0
    hitbox.shape = shape
    add_child(hitbox)
    start_y = position.y
    body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
    clock += delta
    position.y = start_y + sin(clock * 2.7) * 5.0
    rotation = sin(clock * 1.8) * 0.10
    queue_redraw()

func _draw() -> void:
    draw_circle(Vector2.ZERO, 19.0, Color(1.0, 0.83, 0.35, 0.13))
    draw_circle(Vector2.ZERO, 12.0, Color("f5c65e"))
    draw_colored_polygon(PackedVector2Array([Vector2(0,-12),Vector2(9,0),Vector2(0,12),Vector2(-9,0)]), Color("ffe9a0"))
    draw_colored_polygon(PackedVector2Array([Vector2(0,-8),Vector2(5,0),Vector2(0,8)]), Color("f1ac49"))
    draw_line(Vector2(-3,-5), Vector2(-3,5), Color(1.0,1.0,0.9,0.65), 1.5, true)

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player"):
        collected.emit(value)
        queue_free()
