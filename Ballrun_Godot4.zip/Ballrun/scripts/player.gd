extends CharacterBody2D

signal died

const RADIUS := 23.0
const MAX_SPEED := 345.0
const GROUND_ACCEL := 1450.0
const AIR_ACCEL := 760.0
const GROUND_FRICTION := 1850.0
const AIR_FRICTION := 170.0
const GRAVITY := 1120.0
const JUMP_SPEED := -625.0
const MAX_FALL_SPEED := 900.0

var coyote_timer := 0.0
var jump_buffer := 0.0
var controls_enabled := true
var invulnerable_timer := 0.0
var roll_angle := 0.0

func _ready() -> void:
    add_to_group("player")
    collision_layer = 1
    collision_mask = 1
    var hitbox := CollisionShape2D.new()
    var circle := CircleShape2D.new()
    circle.radius = RADIUS - 2.0
    hitbox.shape = circle
    add_child(hitbox)
    z_index = 10

func _physics_process(delta: float) -> void:
    if not controls_enabled:
        velocity.x = move_toward(velocity.x, 0.0, 1800.0 * delta)
        velocity.y = minf(velocity.y + GRAVITY * delta, MAX_FALL_SPEED)
        move_and_slide()
        return

    if is_on_floor():
        coyote_timer = 0.17
    else:
        coyote_timer = maxf(0.0, coyote_timer - delta)

    jump_buffer = maxf(0.0, jump_buffer - delta)
    invulnerable_timer = maxf(0.0, invulnerable_timer - delta)

    if Input.is_action_just_pressed("jump"):
        jump_buffer = 0.18
    if Input.is_action_just_released("jump") and velocity.y < -190.0:
        velocity.y *= 0.57

    var axis := Input.get_axis("move_left", "move_right")
    if absf(axis) > 0.01:
        var acceleration := GROUND_ACCEL if is_on_floor() else AIR_ACCEL
        velocity.x = move_toward(velocity.x, axis * MAX_SPEED, acceleration * delta)
    else:
        var friction := GROUND_FRICTION if is_on_floor() else AIR_FRICTION
        velocity.x = move_toward(velocity.x, 0.0, friction * delta)

    if jump_buffer > 0.0 and coyote_timer > 0.0:
        velocity.y = JUMP_SPEED
        jump_buffer = 0.0
        coyote_timer = 0.0

    velocity.y = minf(velocity.y + GRAVITY * delta, MAX_FALL_SPEED)
    move_and_slide()

    if is_on_floor():
        roll_angle += velocity.x / RADIUS * delta
    if global_position.y > 940.0:
        die()
    queue_redraw()

func die() -> void:
    if not controls_enabled or invulnerable_timer > 0.0:
        return
    controls_enabled = false
    died.emit()

func respawn(at_position: Vector2) -> void:
    global_position = at_position
    velocity = Vector2.ZERO
    roll_angle = 0.0
    coyote_timer = 0.0
    jump_buffer = 0.0
    invulnerable_timer = 0.9
    controls_enabled = true
    queue_redraw()

func _draw() -> void:
    var alpha := 1.0
    if invulnerable_timer > 0.0 and int(Time.get_ticks_msec() / 90) % 2 == 0:
        alpha = 0.55

    draw_circle(Vector2(0, 5), RADIUS + 5.0, Color(0.04, 0.20, 0.24, 0.16 * alpha))
    for i in range(22, 0, -1):
        var t := 1.0 - float(i) / 22.0
        var radius := RADIUS * float(i) / 22.0
        var shade := Color(0.025, 0.30, 0.39, alpha).lerp(Color(0.34, 0.96, 0.88, alpha), t)
        draw_circle(Vector2.ZERO, radius, shade)

    draw_set_transform(Vector2.ZERO, roll_angle, Vector2.ONE)
    draw_arc(Vector2.ZERO, 15.5, -2.25, 0.65, 40, Color(0.78, 1.0, 0.94, 0.76 * alpha), 2.2, true)
    draw_arc(Vector2.ZERO, 18.0, 0.55, 2.55, 40, Color(0.015, 0.31, 0.39, 0.58 * alpha), 2.4, true)
    draw_circle(Vector2(-8.0, -9.0), 5.0, Color(1.0, 1.0, 1.0, 0.9 * alpha))
    draw_circle(Vector2(-6.7, -10.5), 2.0, Color(1.0, 1.0, 1.0, alpha))
    draw_circle(Vector2(9.0, 7.0), 2.3, Color(0.82, 1.0, 0.88, alpha))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
