extends Node2D

@export var camera_target: Camera2D
@export var mood := 0

const SKY_TOP := Color("86c9df")
const SKY_BOTTOM := Color("f4d6a1")

func _ready() -> void:
    z_index = -100
    queue_redraw()

func _process(_delta: float) -> void:
    if is_instance_valid(camera_target):
        position.x = camera_target.global_position.x * 0.14

func _draw() -> void:
    var top := SKY_TOP if mood == 0 else Color("819fc7")
    var bottom := SKY_BOTTOM if mood == 0 else Color("d8b9ab")
    for i in range(720):
        var amount := float(i) / 719.0
        draw_rect(Rect2(-2300.0, float(i), 5400.0, 1.2), top.lerp(bottom, amount))

    var sun_color := Color(1.0, 0.91, 0.63, 0.22) if mood == 0 else Color(1.0, 0.79, 0.68, 0.18)
    for i in range(6, 0, -1):
        draw_circle(Vector2(720.0, 160.0), 34.0 + float(i) * 17.0, Color(sun_color.r, sun_color.g, sun_color.b, sun_color.a / float(i)))
    draw_circle(Vector2(720.0, 160.0), 35.0, Color("fff0bd"))

    draw_rect(Rect2(-2300.0, 756.0, 5400.0, 420.0), Color("668f75"))

    for i in range(-5, 12):
        var x := float(i) * 520.0 - 150.0
        var peak := 320.0 + float((i * 37) % 90)
        var mountains := PackedVector2Array([
            Vector2(x - 290.0, 530.0), Vector2(x - 80.0, peak),
            Vector2(x + 120.0, 500.0), Vector2(x + 300.0, 380.0),
            Vector2(x + 560.0, 535.0)
        ])
        draw_colored_polygon(mountains, Color("91b9b3") if mood == 0 else Color("7186a1"))
        draw_colored_polygon(PackedVector2Array([
            Vector2(x + 38.0, peak + 80.0), Vector2(x + 120.0, 500.0),
            Vector2(x + 300.0, 380.0), Vector2(x + 394.0, 474.0),
            Vector2(x + 300.0, 445.0), Vector2(x + 250.0, 491.0)
        ]), Color(0.88, 0.94, 0.88, 0.50))

    for i in range(-8, 18):
        var x := float(i) * 310.0 - 180.0
        var hill := PackedVector2Array([
            Vector2(x - 160.0, 620.0), Vector2(x - 80.0, 525.0),
            Vector2(x + 80.0, 548.0), Vector2(x + 200.0, 505.0),
            Vector2(x + 370.0, 620.0)
        ])
        draw_colored_polygon(hill, Color("76a98e") if mood == 0 else Color("657e91"))

    for i in range(-9, 22):
        var x := float(i) * 190.0 + 40.0
        var tree_color := Color("4f8b70") if i % 2 == 0 else Color("5d9778")
        draw_rect(Rect2(x - 5.0, 510.0, 10.0, 118.0), Color("85634b"))
        draw_circle(Vector2(x, 493.0), 39.0, tree_color)
        draw_circle(Vector2(x - 23.0, 510.0), 27.0, tree_color.lightened(0.05))
        draw_circle(Vector2(x + 24.0, 511.0), 28.0, tree_color.darkened(0.08))
