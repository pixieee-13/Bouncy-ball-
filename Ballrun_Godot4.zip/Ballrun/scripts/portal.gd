extends Area2D

signal reached
var clock := 0.0
var triggered := false

func _ready() -> void:
    collision_layer = 0
    collision_mask = 1
    var hitbox := CollisionShape2D.new()
    var shape := CircleShape2D.new()
    shape.radius = 46.0
    hitbox.shape = shape
    add_child(hitbox)
    body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
    clock += delta
    queue_redraw()

func _draw() -> void:
    draw_circle(Vector2.ZERO, 57.0, Color(0.27, 0.85, 0.79, 0.09))
    draw_arc(Vector2.ZERO, 39.0, 0.0, TAU, 64, Color("75e5c2"), 7.0, true)
    draw_arc(Vector2.ZERO, 28.0, clock * 0.55, clock * 0.55 + PI * 1.65, 44, Color("fff0ba"), 3.2, true)
    draw_arc(Vector2.ZERO, 18.0, -clock * 0.75, -clock * 0.75 + PI * 1.50, 36, Color("9cf5e8"), 2.5, true)
    for i in range(5):
        var a := clock * 0.7 + float(i) * TAU / 5.0
        var p := Vector2(cos(a), sin(a)) * 33.0
        draw_circle(p, 2.5, Color("fff0b3"))

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player") and not triggered:
        triggered = true
        reached.emit()
