extends StaticBody2D

@export var dimensions := Vector2(280.0, 48.0)
@export var theme := 0

func _ready() -> void:
    collision_layer = 1
    collision_mask = 0
    var hitbox := CollisionShape2D.new()
    var shape := RectangleShape2D.new()
    shape.size = dimensions
    hitbox.shape = shape
    hitbox.position = dimensions * 0.5
    add_child(hitbox)
    queue_redraw()

func _draw() -> void:
    var body_color := Color("326f62") if theme == 0 else Color("536a83")
    var top_color := Color("7fc78a") if theme == 0 else Color("9bbbd0")
    var shade_color := Color("245449") if theme == 0 else Color("394f67")

    draw_rect(Rect2(0.0, 10.0, dimensions.x, dimensions.y - 10.0), body_color)
    draw_rect(Rect2(0.0, 8.0, dimensions.x, dimensions.y - 8.0), shade_color, false, 1.0)
    draw_rect(Rect2(0.0, 0.0, dimensions.x, 15.0), top_color)
    draw_rect(Rect2(0.0, 12.0, dimensions.x, 4.0), top_color.darkened(0.20))
    draw_line(Vector2(9.0, 3.0), Vector2(dimensions.x - 9.0, 3.0), Color(0.91, 0.98, 0.72, 0.52), 2.0, true)

    var count := int(dimensions.x / 82.0)
    for i in range(count):
        var px := 26.0 + float(i) * 79.0
        if px < dimensions.x - 14.0:
            draw_circle(Vector2(px, 29.0 + float(i % 2) * 7.0), 2.3, Color(0.80, 0.91, 0.70, 0.18))
            draw_circle(Vector2(px + 25.0, 42.0), 1.6, Color(0.10, 0.27, 0.30, 0.18))

    for blade in range(int(dimensions.x / 54.0)):
        var bx := 24.0 + float(blade) * 54.0
        draw_line(Vector2(bx, 1.0), Vector2(bx - 3.0, -4.0), Color(0.59, 0.83, 0.49, 0.85), 1.5, true)
        draw_line(Vector2(bx + 2.0, 2.0), Vector2(bx + 5.0, -3.0), Color(0.67, 0.89, 0.54, 0.8), 1.4, true)
