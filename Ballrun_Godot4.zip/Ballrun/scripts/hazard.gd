extends Area2D

@export var dimensions := Vector2(72.0, 30.0)

func _ready() -> void:
    collision_layer = 0
    collision_mask = 1
    var hitbox := CollisionShape2D.new()
    var shape := RectangleShape2D.new()
    shape.size = Vector2(dimensions.x, dimensions.y * 0.78)
    hitbox.shape = shape
    hitbox.position = Vector2(dimensions.x * 0.5, dimensions.y * 0.56)
    add_child(hitbox)
    body_entered.connect(_on_body_entered)
    queue_redraw()

func _draw() -> void:
    var count := max(1, int(dimensions.x / 25.0))
    var spike_width := dimensions.x / float(count)
    for i in range(count):
        var x := float(i) * spike_width
        var points := PackedVector2Array([
            Vector2(x, dimensions.y),
            Vector2(x + spike_width * 0.50, 2.0),
            Vector2(x + spike_width, dimensions.y)
        ])
        draw_colored_polygon(points, Color("f17b67"))
        draw_line(Vector2(x + spike_width * 0.50, 3.0), Vector2(x + spike_width * 0.30, dimensions.y - 3.0), Color(1.0, 0.82, 0.69, 0.8), 1.7, true)
    draw_line(Vector2(0.0, dimensions.y), Vector2(dimensions.x, dimensions.y), Color("9a514f"), 3.0, true)

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player"):
        body.call("die")
