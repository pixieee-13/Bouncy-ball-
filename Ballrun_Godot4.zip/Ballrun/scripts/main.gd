extends Node2D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const LEVEL_SCRIPT = preload("res://scripts/level_builder.gd")

var level_node: Variant
var player: Variant
var camera: Camera2D
var active_level := 0
var total_coins := 0
var deaths := 0
var run_time := 0.0
var checkpoint_position := Vector2(110, 588)
var game_started := false
var is_paused := false
var is_transitioning := false

var ui_layer: CanvasLayer
var hud_root: Control
var menu_root: Control
var overlay_root: Control
var level_label: Label
var coin_label: Label
var deaths_label: Label
var time_label: Label
var banner_label: Label

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _build_ui()
    _show_title_screen()

func _process(delta: float) -> void:
    if game_started and not is_paused and not is_transitioning:
        run_time += delta
        _update_hud()
    if game_started and Input.is_action_just_pressed("pause"):
        _toggle_pause()
    if game_started and Input.is_action_just_pressed("restart") and not is_transitioning:
        _respawn_player()

func _build_ui() -> void:
    ui_layer = CanvasLayer.new()
    ui_layer.layer = 30
    ui_layer.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(ui_layer)

    hud_root = Control.new()
    hud_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud_root.process_mode = Node.PROCESS_MODE_ALWAYS
    ui_layer.add_child(hud_root)
    _build_hud()

func _build_hud() -> void:
    var panel := PanelContainer.new()
    panel.position = Vector2(24, 20)
    panel.size = Vector2(790, 62)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.035, 0.105, 0.14, 0.82)
    style.border_color = Color(0.58, 0.88, 0.78, 0.45)
    style.set_border_width_all(1)
    style.set_corner_radius_all(16)
    style.content_margin_left = 18
    style.content_margin_right = 15
    style.content_margin_top = 8
    style.content_margin_bottom = 8
    panel.add_theme_stylebox_override("panel", style)
    hud_root.add_child(panel)

    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 22)
    row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    panel.add_child(row)

    level_label = _label("MEADOW PATH", 17, Color("d8f4dd"))
    level_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(level_label)
    coin_label = _label("✦  0", 17, Color("ffdf8a"))
    row.add_child(coin_label)
    deaths_label = _label("Falls  0", 15, Color("f2c1b0"))
    row.add_child(deaths_label)
    time_label = _label("00:00", 15, Color("eef7ed"))
    row.add_child(time_label)

    var pause_button := Button.new()
    pause_button.text = "Ⅱ"
    pause_button.custom_minimum_size = Vector2(42, 38)
    _style_button(pause_button, Color("326b66"), Color("b4e6c8"))
    pause_button.pressed.connect(_toggle_pause)
    row.add_child(pause_button)

    var controls := _label("A / D or ← / →  MOVE        SPACE  JUMP        R  RESPAWN        ESC  PAUSE", 13, Color(0.11,0.23,0.25,0.8))
    controls.position = Vector2(28, 676)
    controls.size = Vector2(880, 25)
    hud_root.add_child(controls)

    banner_label = _label("", 19, Color("f8fff0"))
    banner_label.position = Vector2(150, 100)
    banner_label.size = Vector2(980, 42)
    banner_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hud_root.add_child(banner_label)
    hud_root.hide()

func _show_title_screen() -> void:
    if is_instance_valid(menu_root):
        menu_root.queue_free()
    menu_root = Control.new()
    menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu_root.process_mode = Node.PROCESS_MODE_ALWAYS
    ui_layer.add_child(menu_root)

    var bg := ColorRect.new()
    bg.color = Color("183c49")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu_root.add_child(bg)
    var glow := ColorRect.new()
    glow.color = Color(0.42, 0.75, 0.63, 0.18)
    glow.position = Vector2(0, 420)
    glow.size = Vector2(1280, 300)
    menu_root.add_child(glow)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu_root.add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(600, 475)
    var card_style := StyleBoxFlat.new()
    card_style.bg_color = Color(0.035, 0.105, 0.14, 0.93)
    card_style.border_color = Color(0.60, 0.86, 0.73, 0.75)
    card_style.set_border_width_all(2)
    card_style.set_corner_radius_all(28)
    card_style.content_margin_left = 44
    card_style.content_margin_right = 44
    card_style.content_margin_top = 38
    card_style.content_margin_bottom = 34
    panel.add_theme_stylebox_override("panel", card_style)
    center.add_child(panel)

    var content := VBoxContainer.new()
    content.add_theme_constant_override("separation", 16)
    content.alignment = BoxContainer.ALIGNMENT_CENTER
    panel.add_child(content)

    var eyebrow := _label("A LITTLE ADVENTURE FOR YOUR ORB", 13, Color("a7d5be"))
    content.add_child(eyebrow)
    var title := _label("BALLRUN", 48, Color("f1ffe8"))
    title.add_theme_font_size_override("font_size", 48)
    content.add_child(title)
    var subtitle := _label("MEADOW RUN", 17, Color("f4d58e"))
    content.add_child(subtitle)
    var description := _label("Roll, hop and collect glowing seeds across\nthree cheerful little worlds.", 17, Color("c5e0d5"))
    description.custom_minimum_size = Vector2(470, 56)
    content.add_child(description)

    var play := Button.new()
    play.text = "PLAY ADVENTURE"
    play.custom_minimum_size = Vector2(300, 58)
    _style_button(play, Color("3b9b79"), Color("b9efbd"))
    play.pressed.connect(_start_new_game)
    content.add_child(play)

    var controls := _label("MOVE  A / D or arrows      JUMP  Space / W / ↑", 14, Color("b7d2c9"))
    content.add_child(controls)
    var friendly := _label("Easy first level  •  checkpoints  •  no rush", 13, Color("8fb8a6"))
    content.add_child(friendly)

func _start_new_game() -> void:
    get_tree().paused = false
    if is_instance_valid(menu_root):
        menu_root.queue_free()
    if is_instance_valid(overlay_root):
        overlay_root.queue_free()
    total_coins = 0
    deaths = 0
    run_time = 0.0
    active_level = 0
    game_started = true
    is_paused = false
    is_transitioning = false
    _start_level(active_level)
    hud_root.show()
    _update_hud()

func _start_level(index: int) -> void:
    if is_instance_valid(level_node):
        level_node.queue_free()
    if is_instance_valid(player):
        player.queue_free()

    active_level = index

    player = CharacterBody2D.new()
    player.set_script(PLAYER_SCRIPT)
    player.process_mode = Node.PROCESS_MODE_PAUSABLE
    add_child(player)

    camera = Camera2D.new()
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 5.5
    camera.offset = Vector2(0.0, -55.0)
    camera.limit_left = 0
    camera.limit_top = 0
    camera.limit_bottom = 900
    player.add_child(camera)
    camera.make_current()

    var builder: Variant = Node2D.new()
    builder.set_script(LEVEL_SCRIPT)
    builder.process_mode = Node.PROCESS_MODE_PAUSABLE
    builder.level_index = index
    builder.camera_target = camera
    level_node = builder
    add_child(level_node)
    camera.limit_right = int(level_node.world_width)
    player.position = level_node.spawn_position

    level_node.coin_collected.connect(_on_coin_collected)
    level_node.checkpoint_activated.connect(_on_checkpoint_activated)
    level_node.level_finished.connect(_on_level_finished)
    checkpoint_position = level_node.spawn_position
    player.died.connect(_on_player_died)
    banner_label.text = level_node.level_subtitle
    banner_label.modulate.a = 1.0
    var fade := create_tween()
    fade.tween_property(banner_label, "modulate:a", 0.0, 2.5).set_delay(1.4)
    _update_hud()

func _on_coin_collected(value: int) -> void:
    total_coins += value
    _update_hud()
    _show_banner("+%d GLOWING SEED" % value)

func _on_checkpoint_activated(spawn_at: Vector2) -> void:
    checkpoint_position = spawn_at
    _show_banner("CHECKPOINT SAVED")

func _show_banner(message: String) -> void:
    banner_label.text = message
    banner_label.modulate.a = 1.0
    var fade := create_tween()
    fade.tween_property(banner_label, "modulate:a", 0.0, 1.2).set_delay(0.65)

func _on_player_died() -> void:
    if is_transitioning:
        return
    deaths += 1
    _update_hud()
    _show_banner("THAT'S OK — TRY AGAIN!")
    await get_tree().create_timer(0.65).timeout
    if is_instance_valid(player) and game_started:
        player.respawn(checkpoint_position)

func _respawn_player() -> void:
    if is_instance_valid(player):
        player.respawn(checkpoint_position)
        _show_banner("BACK AT CHECKPOINT")

func _on_level_finished() -> void:
    if is_transitioning:
        return
    is_transitioning = true
    player.controls_enabled = false
    player.velocity = Vector2.ZERO
    if active_level < 2:
        _show_overlay("WORLD COMPLETE", "You finished %s.\nSeeds collected: %d" % [level_node.level_name, total_coins], "NEXT WORLD", _go_next_level)
    else:
        _show_overlay("YOU DID IT!", "All three worlds explored.\nSeeds: %d     Falls: %d\nTime: %s" % [total_coins, deaths, _format_time(run_time)], "PLAY AGAIN", _start_new_game)

func _go_next_level() -> void:
    if is_instance_valid(overlay_root):
        overlay_root.queue_free()
    is_transitioning = false
    _start_level(active_level + 1)

func _toggle_pause() -> void:
    if not game_started or is_transitioning:
        return
    is_paused = not is_paused
    get_tree().paused = is_paused
    if is_paused:
        _show_overlay("TAKE A BREAK", "Your progress is safe.\nPress Resume when you're ready.", "RESUME", _toggle_pause, true)
    elif is_instance_valid(overlay_root):
        overlay_root.queue_free()

func _show_overlay(title_text: String, body_text: String, button_text: String, callback: Callable, pause_tree: bool = false) -> void:
    if is_instance_valid(overlay_root):
        overlay_root.queue_free()
    overlay_root = Control.new()
    overlay_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay_root.process_mode = Node.PROCESS_MODE_ALWAYS
    ui_layer.add_child(overlay_root)

    var shade := ColorRect.new()
    shade.color = Color(0.015, 0.07, 0.09, 0.72)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay_root.add_child(shade)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay_root.add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(540, 340)
    var style := StyleBoxFlat.new()
    style.bg_color = Color("173c43")
    style.border_color = Color("a7dfb7")
    style.set_border_width_all(2)
    style.set_corner_radius_all(24)
    style.content_margin_left = 36
    style.content_margin_right = 36
    style.content_margin_top = 34
    style.content_margin_bottom = 34
    panel.add_theme_stylebox_override("panel", style)
    center.add_child(panel)
    var content := VBoxContainer.new()
    content.add_theme_constant_override("separation", 18)
    content.alignment = BoxContainer.ALIGNMENT_CENTER
    panel.add_child(content)
    var title := _label(title_text, 32, Color("f3ffe9"))
    content.add_child(title)
    var body := _label(body_text, 16, Color("c4dfd0"))
    body.custom_minimum_size = Vector2(440, 70)
    content.add_child(body)
    var button := Button.new()
    button.text = button_text
    button.custom_minimum_size = Vector2(250, 56)
    _style_button(button, Color("3b9b79"), Color("b9efbd"))
    button.pressed.connect(callback)
    var button_center := CenterContainer.new()
    button_center.add_child(button)
    content.add_child(button_center)

    if pause_tree:
        get_tree().paused = true

func _update_hud() -> void:
    if not is_instance_valid(coin_label):
        return
    coin_label.text = "✦  %d" % total_coins
    deaths_label.text = "Falls  %d" % deaths
    time_label.text = _format_time(run_time)
    if is_instance_valid(level_node):
        level_label.text = "%d / 3   %s" % [active_level + 1, level_node.level_name]

func _format_time(seconds: float) -> String:
    var whole := int(seconds)
    return "%02d:%02d" % [int(whole / 60), whole % 60]

func _label(text_value: String, size: int, color: Color) -> Label:
    var item := Label.new()
    item.text = text_value
    item.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    item.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    item.add_theme_font_size_override("font_size", size)
    item.add_theme_color_override("font_color", color)
    item.add_theme_color_override("font_shadow_color", Color(0,0,0,0.18))
    item.add_theme_constant_override("shadow_offset_x", 1)
    item.add_theme_constant_override("shadow_offset_y", 1)
    return item

func _style_button(button: Button, fill: Color, outline: Color) -> void:
    for state in ["normal", "hover", "pressed", "focus", "disabled"]:
        var box := StyleBoxFlat.new()
        box.bg_color = fill.darkened(0.12) if state == "pressed" else fill.lightened(0.10) if state == "hover" else fill
        box.border_color = outline
        box.set_border_width_all(2)
        box.set_corner_radius_all(14)
        box.content_margin_left = 18
        box.content_margin_right = 18
        box.content_margin_top = 10
        box.content_margin_bottom = 10
        button.add_theme_stylebox_override(state, box)
    button.add_theme_font_size_override("font_size", 17)
    button.add_theme_color_override("font_color", Color("f5fff1"))
    button.add_theme_color_override("font_hover_color", Color.WHITE)
    button.add_theme_color_override("font_pressed_color", Color.WHITE)
