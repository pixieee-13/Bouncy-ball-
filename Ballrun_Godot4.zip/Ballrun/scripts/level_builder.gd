extends Node2D

signal coin_collected(value: int)
signal checkpoint_activated(spawn_position: Vector2)
signal level_finished

const PLATFORM_SCRIPT = preload("res://scripts/platform.gd")
const COIN_SCRIPT = preload("res://scripts/coin.gd")
const HAZARD_SCRIPT = preload("res://scripts/hazard.gd")
const CHECKPOINT_SCRIPT = preload("res://scripts/checkpoint.gd")
const PORTAL_SCRIPT = preload("res://scripts/portal.gd")
const ENEMY_SCRIPT = preload("res://scripts/enemy.gd")
const BACKDROP_SCRIPT = preload("res://scripts/backdrop.gd")

var level_index := 0
var camera_target: Camera2D
var world_width := 2100.0
var spawn_position := Vector2(100, 588)
var level_name := "MEADOW PATH"
var level_subtitle := "A gentle first roll. Take your time."

const LEVELS := [
    {
        "name": "MEADOW PATH", "subtitle": "A gentle first roll. Take your time.", "width": 2100.0, "mood": 0,
        "spawn": Vector2(110, 588),
        "platforms": [[0,610,650,180],[750,565,330,48],[1180,520,330,48],[1610,570,560,180]],
        "coins": [[835,510],[1260,465],[1510,465],[1755,510],[1930,510]],
        "hazards": [], "enemies": [], "checkpoint": [1320,520], "goal": [2010,510]
    },
    {
        "name": "RIVER ROCKS", "subtitle": "A few safe hops and one sleepy little guard.", "width": 2500.0, "mood": 0,
        "spawn": Vector2(110,588),
        "platforms": [[0,610,560,180],[660,570,320,48],[1080,525,330,48],[1510,565,340,48],[1950,520,520,180]],
        "coins": [[745,515],[1165,470],[1370,470],[1600,510],[2070,460],[2290,460]],
        "hazards": [[2210,492,58,28]], "enemies": [[1655,540,90,0.85]], "checkpoint": [1640,565], "goal": [2390,460]
    },
    {
        "name": "CLOUD GARDEN", "subtitle": "The last stretch. Keep your jumps calm and steady.", "width": 2700.0, "mood": 1,
        "spawn": Vector2(110,588),
        "platforms": [[0,610,520,180],[625,570,300,48],[1030,525,300,48],[1435,565,320,48],[1860,515,330,48],[2300,560,500,180]],
        "coins": [[710,515],[1110,470],[1510,510],[1950,460],[2100,460],[2420,500],[2610,500]],
        "hazards": [[1685,535,55,28],[2495,532,58,28]], "enemies": [[820,545,58,0.7],[1980,490,75,0.8]], "checkpoint": [1950,515], "goal": [2690,500]
    }
]

func _ready() -> void:
    _build()

func _build() -> void:
    var data: Dictionary = LEVELS[clampi(level_index, 0, LEVELS.size() - 1)]
    level_name = data["name"]
    level_subtitle = data["subtitle"]
    world_width = data["width"]
    spawn_position = data["spawn"]

    var backdrop: Variant = Node2D.new()
    backdrop.set_script(BACKDROP_SCRIPT)
    backdrop.camera_target = camera_target
    backdrop.mood = data["mood"]
    add_child(backdrop)

    for item in data["platforms"]:
        _add_platform(Vector2(item[0], item[1]), Vector2(item[2], item[3]), level_index if level_index == 2 else 0)
    for item in data["hazards"]:
        _add_hazard(Vector2(item[0], item[1]), Vector2(item[2], item[3]))
    for item in data["coins"]:
        _add_coin(Vector2(item[0], item[1]))
    for item in data["enemies"]:
        _add_enemy(Vector2(item[0], item[1]), item[2], item[3])
    _add_checkpoint(Vector2(data["checkpoint"][0], data["checkpoint"][1]))
    _add_portal(Vector2(data["goal"][0], data["goal"][1]))

func _add_platform(at: Vector2, dimensions: Vector2, theme: int) -> void:
    var platform: Variant = StaticBody2D.new()
    platform.set_script(PLATFORM_SCRIPT)
    platform.dimensions = dimensions
    platform.theme = theme
    platform.position = at
    add_child(platform)

func _add_hazard(at: Vector2, dimensions: Vector2) -> void:
    var hazard: Variant = Area2D.new()
    hazard.set_script(HAZARD_SCRIPT)
    hazard.dimensions = dimensions
    hazard.position = at
    add_child(hazard)

func _add_coin(at: Vector2) -> void:
    var coin: Variant = Area2D.new()
    coin.set_script(COIN_SCRIPT)
    coin.position = at
    coin.collected.connect(_on_coin_collected)
    add_child(coin)

func _add_enemy(at: Vector2, patrol: float, speed: float) -> void:
    var enemy: Variant = Area2D.new()
    enemy.set_script(ENEMY_SCRIPT)
    enemy.patrol_distance = patrol
    enemy.move_speed = speed
    enemy.position = at
    add_child(enemy)

func _add_checkpoint(at: Vector2) -> void:
    var checkpoint: Variant = Area2D.new()
    checkpoint.set_script(CHECKPOINT_SCRIPT)
    checkpoint.position = at
    checkpoint.activated.connect(_on_checkpoint_activated)
    add_child(checkpoint)

func _add_portal(at: Vector2) -> void:
    var portal: Variant = Area2D.new()
    portal.set_script(PORTAL_SCRIPT)
    portal.position = at
    portal.reached.connect(_on_level_finished)
    add_child(portal)

func _on_coin_collected(value: int) -> void:
    coin_collected.emit(value)

func _on_checkpoint_activated(spawn_at: Vector2) -> void:
    checkpoint_activated.emit(spawn_at)

func _on_level_finished() -> void:
    level_finished.emit()
