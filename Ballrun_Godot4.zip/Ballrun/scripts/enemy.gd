extends Area2D

@export var patrol_distance := 90.0
@export var move_speed := 1.0
var start_x := 0.0
var clock := 0.0

func _ready() -> void:
    collision_layer = 0
    collision_mask = 1
    start_x = position.x
    var hitbox := CollisionShape2D.new()
    var shape := CircleShape2D.new()
    shape.radius = 20.0
    hitbox.shape = shape
    add_child(hitbox)
    body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
    clock += delta
    position.x = start_x + sin(clock * move_speed) * patrol_distance * 0.5
    queue_redraw()

func _draw() -> void:
    var squash := 1.0 + sin(clock * 5.0) * 0.07
    draw_set_transform(Vector2(0, 4), 0.0, Vector2(1.0, squash))
    draw_circle(Vector2.ZERO, 18.0, Color("4e887c"))
    draw_circle(Vector2(-6,-3), 4.1, Color("f4f4d7"))
    draw_circle(Vector2(6,-3), 4.1, Color("f4f4d7"))
    draw_circle(Vector2(-5,-2), 1.8, Color("263c45"))
    draw_circle(Vector2(7,-2), 1.8, Color("263c45"))
    draw_arc(Vector2(0, 2), 6.0, 0.3, 2.8, 16, Color("244a4b"), 1.5, true)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _on_body_entered(body: Node2D) -> void:
    if body.is_in_group("player"):
        body.call("die")
