# BALLRUN: Meadow Run

A redesigned, beginner-friendly 2D rolling-ball platformer for **Godot 4.3 or newer**.

## What's changed in this edition

- Replaced stretched atlas crops with clean, smoothly drawn vector-style scenery and platforms.
- Kept one consistent visual style across the orb, platforms, collectibles, hazards, enemies, and UI.
- Made the first level a relaxed tutorial with wide platforms and no hazards.
- Reduced movement speed and made jumping more forgiving with coyote time and jump buffering.
- Added checkpoints and quick respawn so a mistake never means replaying a whole level.
- Three short worlds with gentle difficulty progression.

## Run it

1. Extract the ZIP.
2. Open **Godot Project Manager**.
3. Choose **Import** and select `Ballrun/project.godot`.
4. Open the project and press **F5**.

## Controls

| Action | Keys |
|---|---|
| Move | A / D or Left / Right arrows |
| Jump | Space, W, or Up arrow |
| Pause | Esc |
| Respawn at checkpoint | R |

Hold Jump a little longer for a higher jump. The first area is intentionally safe so you can get used to the ball's movement.

## Notes on the art

The two supplied packs use small pixel-art sprites. The previous version enlarged arbitrary atlas crops to fill wide platforms, which caused the visible stretching and rough seams. This redesign uses clean vector-style drawing throughout the game instead of stretching those incompatible sprites. The original uploads are not modified.
